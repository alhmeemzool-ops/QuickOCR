package com.hamam.quickocr

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textview.MaterialTextView
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: MaterialTextView
    private lateinit var progress: LinearProgressIndicator
    private lateinit var imageCapture: ImageCapture
    private lateinit var cameraExecutor: ExecutorService
    private var captureStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)
        preview = findViewById(R.id.preview)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        cameraExecutor = Executors.newSingleThreadExecutor()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
        } else startCamera()
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        if (r == 10 && g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) startCamera()
        else { Toast.makeText(this, "يجب السماح بالكاميرا", Toast.LENGTH_LONG).show(); finish() }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = androidx.camera.core.Preview.Builder().build()
            previewUseCase.surfaceProvider = preview.surfaceProvider
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, imageCapture)
            if (!captureStarted) {
                captureStarted = true
                preview.postDelayed({ takePhoto() }, 900)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        status.text = "جاري التقاط الصورة..."
        val photoFile = File(cacheDir, "ocr_photo.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(photoFile).build()
        imageCapture.takePicture(output, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                val bitmap = BitmapFactory.decodeFile(photoFile.absolutePath)
                runOnUiThread { status.text = "جاري استخراج النص..." }
                if (bitmap != null) cameraExecutor.execute { recognize(bitmap) }
                else runOnUiThread {
                    Toast.makeText(this@CameraActivity, "تعذر قراءة الصورة", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread {
                    Toast.makeText(this@CameraActivity, "تعذر التقاط الصورة", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        })
    }

    private fun recognize(bitmap: Bitmap) {
        try {
            val dataDir = File(filesDir, "tessdata")
            if (!dataDir.exists()) dataDir.mkdirs()
            val trained = File(dataDir, "ara.traineddata")
            if (!trained.exists()) {
                assets.open("tessdata/ara.traineddata").use { input ->
                    FileOutputStream(trained).use { output -> input.copyTo(output) }
                }
            }
            val tess = TessBaseAPI()
            tess.init(filesDir.absolutePath, "ara+eng", TessBaseAPI.OEM_LSTM_ONLY)
            tess.setImage(bitmap)
            val text = tess.getUTF8Text()?.trim().orEmpty()
            tess.recycle()

            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("OCR", text))

            runOnUiThread {
                progress.progress = 100
                status.text = if (text.isBlank()) "لم يتم العثور على نص" else "تم نسخ النص إلى الحافظة ✓"
                Toast.makeText(this, if (text.isBlank()) "لم يتم العثور على نص" else "تم النسخ — جاهز للصق", Toast.LENGTH_SHORT).show()
                preview.postDelayed({ finish() }, 900)
            }
        } catch (e: Exception) {
            runOnUiThread {
                Toast.makeText(this, "خطأ OCR: ${e.message}", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}

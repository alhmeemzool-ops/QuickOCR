package com.hamam.quickocr

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.KeyEvent

class VolumeAccessibilityService : AccessibilityService() {
    private var count = 0
    private var lastDown = 0L

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN ||
            event.repeatCount != 0 ||
            event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false

        val now = SystemClock.elapsedRealtime()
        if (now - lastDown > 1200L) count = 0
        lastDown = now
        count++

        if (count >= 3) {
            count = 0
            val intent = Intent(this, CameraActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            return true
        }
        return false
    }

    override fun onInterrupt() {}
}
